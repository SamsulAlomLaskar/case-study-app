import React from 'react'

function FallBackUI() {
    return (
        <div>
            <img src = "assets\erro.jpg" />
        </div>
    )
}

export default FallBackUI
